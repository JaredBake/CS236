#pragma once
#include <iostream>
#include "Predicate.h"

using namespace std;

class Rule {
    Predicate* headPredicate;
    vector<Predicate*> predicates;

public:

    Rule(){}

    Rule(Predicate* head, vector<Predicate*> preds){
        headPredicate = head;
        predicates = preds;
    }

    Predicate* getHead(){
        return headPredicate;
    }

    vector<Predicate*> getPredicates(){
        return predicates;
    }

    void assignPredicates(vector<Predicate*> rules){
        predicates == rules;
    }


    string toString(){
        string output = "";

        output.append(headPredicate->toString());
        output.append(" :- ");
        for (unsigned int i = 0; i < predicates.size(); i++)
        {
            output.append(predicates.at(i)->toString());
            if (i < predicates.size()-1) {
                output.append(",");
            }
        }
        output.append(".\n");


        return output;
    }
};