#pragma once
#include <vector>
#include <string>

using namespace std;

class Scheme {
private:

public:
    vector<string> attributes;

    Scheme(){
        attributes = vector<string>();
    }


    Scheme(vector<string> names) {
        attributes = names;

    }

    void addScheme(string thing){
        attributes.push_back(thing);
    }
    void assignAttributes(vector<string> strings){
        attributes = strings;
    }

    string getAttribute(int index){
        string t;
        t = attributes.at(index);
        return t;
    }

    unsigned  size() const {
        return attributes.size();
    }

    const string& at(int index) const{
        return attributes.at(index);
    }

    vector<string> getNames(){
        return attributes;
    }
};