#pragma once
#include <string>
#include <unordered_map>
#include "Rule.h"
#include "Predicate.h"
#include "DatalogProgram.h"
#include "Relation.h"
#include "Database.h"
#include "Graph.h"
#include "Node.h"

using namespace std;

class Interpreter {
private:
    int passes = 0;
    bool repeat = false;
    bool end = false;
    Database data;
    unordered_map<string,int> variables;
    vector<int> indexes;
    vector<string> names;
public:

    Interpreter(){
        data = Database();
    }

    unordered_map<string, int> getVariables(){
        return variables;
    }

    static Graph makeGraph(const vector<Rule>& rules) {

        Graph graph(rules.size());
        for (unsigned fromID = 0; fromID < rules.size(); fromID++) {
            Rule fromRule = rules.at(fromID);
            //cout << "from rule R" << fromID << ": " << fromRule.toString();
            for (unsigned pred = 0; pred < fromRule.size(); pred++) {
                Predicate bodyPred = fromRule.getBodyPredicate(pred);
                //cout << "from body predicate: " << bodyPred.toString() << endl;
                for (unsigned toID = 0; toID < rules.size(); toID++) {
                    Rule toRule = rules.at(toID);
                    //cout << "to rule R" << toID << ": " << toRule.toString();
                    if (toRule.altGetHead().getName() == bodyPred.getName()) {
                        //cout << "dependency found: (R" << fromID << ",R" << toID << ")" << endl;
                        graph.addEdge(fromID,toID);
                    }
                }

            }
        }

        // add code to add edges to the graph for the rule dependencies
        return graph;

    }


    void evaluateRules(vector<Rule*> rules){
        repeat = false;
        vector<Predicate*> predicates;

        for(Rule* R : rules){
            vector<Relation> result;
            //predicates = R->getPredicates();
            //cout << R->toString();
            for (Predicate* p : predicates) {
                Relation r = evaluateQuery(p);
                result.push_back(r);
                //cout << r.toString();
            }
            Relation endResult = result.at(0);
            endResult = endResult.join(endResult);
            //cout << "joining rules" << endl;
            for (unsigned int i = 1; i < result.size(); i++) {
                endResult = endResult.join(result.at(i));
            }
            //cout << endResult.toString();
            // Write code to get indexes for the project function
            Predicate* head = R->getHead();
            vector<string> keys = translateParams(head->getParams());
            vector<string> attribute = endResult.getScheme().getNames();
            indexes.clear();
            names.clear();
            for(unsigned int i = 0; i < keys.size(); i++) {
                for (unsigned int j = 0; j < attribute.size(); ++j) {
                    if (keys.at(i) == attribute.at(j)) {
                        indexes.push_back(j);
                        names.push_back(keys.at(i));
                    }
                }
            }
            //cout << "HERE" << endl;

            endResult = endResult.project(indexes);
            endResult = endResult.rename(names);
            names.clear();
            unordered_map<string,Relation> m = data.getMap();
            Relation r = m.find(head->getName())->second;
            for (unsigned int i = 0; i < endResult.getScheme().getNames().size(); ++i) {
                names.push_back(r.getScheme().getAttribute(i));
            }


            endResult = endResult.rename(names);
            //cout << endResult.toString();
            cout << R->toString();
            // call project on the joined relation to match the head predicate
            Relation* rate = &data.getMap().find(head->getName())->second;
            Union(endResult,rate);



        }
        passes++;
    }

    void Union(Relation newRelation, Relation* oldRelation){
        for (Tuple t : newRelation.getTuples()) {
            if (oldRelation->addTuple(t)){
                //cout << "already in there" << endl;
                cout << t.toString(newRelation.getScheme());
                repeat = true;

            }
        }
    }

    int getPasses(){
        return passes;
    }


    void evaluateQueries(vector<Predicate*> queries){
        //cout << "IN EVALUATE QUERIES!" << endl;
        cout << "Query Evaluation" << endl;
        for (Predicate* query: queries){

            Relation r = evaluateQuery(query);
            cout << query->toString() << "? ";
            if (r.getSize() == 0){
                cout << "No\n";
            }
            else{
                cout << "Yes(" << r.getSize() << ")\n";
                if (query->getParams().size() > 0){
                    cout << r.toString();
                }
            }
        }
    }

    void addFacts(vector<Predicate*> facts){
        for (Predicate* f: facts) {
            string name = f->getName();
            Tuple fact = Tuple();
            vector<string> strings;
            strings = translateParams(f->getParams());
            for (unsigned int i = 0; i < strings.size(); ++i) {
                fact.push_back(strings.at(i));
            }

            // put tuple in fact
            data.addFactToRelation(fact, name);
            //data.getRelation(name).addTuple(fact);
        }
    }

    void addScheme(vector<Predicate*> schemes){
        for (Predicate* p: schemes) {
            string name = p->getName();
            Scheme scheme = Scheme();
            // put params in scheme
            scheme.assignAttributes(translateParams(p->getParams()));
            Relation r(name,scheme);
            data.addRelationToMap(name,r);
        }
    }

    vector<string> translateParams(vector<Parameter*> param){
        vector<string> strings;
        for(Parameter* p: param){
            strings.push_back(p->toString());
        }
        return strings;
    }

    bool repeats(){
        return repeat;
    }


    Relation evaluateQuery(Predicate* query){
//        cout << "IN EVALUATE QUERY!" << endl;
        //cout << "Evaluating query!" << endl;
        variables.clear();
        names.clear();
        indexes.clear();
        Relation r = data.getRelation(query->getName());
        for(unsigned i = 0; i < query->getParams().size(); i++){

            vector<Parameter*> p = query->getParams();
            if (p.at(i)->getBool()){
                r = r.select1(i, p.at(i)->toString());
            }
            else{
                if (variables.find(p.at(i)->toString()) == variables.end()){
                    variables.insert({p.at(i)->toString(),i});
                    indexes.push_back(i);
                    names.push_back(p.at(i)->toString());

                }else {
                    r = r.select2(variables.find(p.at(i)->toString())->second, i);
                }
            }
        }

        r = r.project(indexes);
        r = r.rename(names);

        return r;
    }



};