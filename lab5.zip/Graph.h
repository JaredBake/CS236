#pragma once
#include <iostream>

#include "Interpreter.h"
#include "Node.h"


class Graph {

private:

    map<int,Node> nodes;

public:

    Graph(int size) {
        for (int nodeID = 0; nodeID < size; nodeID++)
            nodes[nodeID] = Node();
    }

    void addEdge(int fromNodeID, int toNodeID) {
        nodes[fromNodeID].addEdge(toNodeID);
    }

    string toString(){
        string output;
        for (auto& pair: nodes) {
            int nodeID = pair.first;
            Node node = pair.second;
            output.append("R");
            output.append(to_string(nodeID));
            output.append(":");
            if (!node.isEmpty()) {
                output.append(node.toString());
            }
            output.append("\n");
        }
        output.pop_back();
        return output;
    }

};