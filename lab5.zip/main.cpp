#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include "Parser.h"
#include "Token.h"
#include "Scanner.h"
#include "Interpreter.h"
#include "Database.h"
#include "Tuple.h"
#include "Scheme.h"
#include "Relation.h"
#include "Node.h"
#include "Graph.h"

using namespace std;
//
//
////  vector<Token> tokens = {
////    Token(ID,"Ned",2),
////    Token(LEFT_PAREN,"(",2),
////    Token(RIGHT_PAREN,")",2),
////  };
//
////  Parser p = Parser(tokens);
////  cout << p.tokenType() << endl;
////  p.advanceToken();
////  cout << p.tokenType() << endl;
//// p.advanceToken();
//// cout << p.tokenType() << endl;
////  p.throwError();
//
//// Parser p = Parser(tokens);
////  p.match(ID);
////  p.match(LEFT_PAREN);
////  p.match(ID);         // intentional error
////  p.match(RIGHT_PAREN);
//
///*
//
//  vector<Token> tokens = {
//    Token(COMMA,",",2),
//   // Token(ID,"Ted",2),
//    Token(COMMA,",",2),
//    Token(ID,"Zed",2),
//    Token(RIGHT_PAREN,")",2),
//  };
//
//  Parser p = Parser(tokens);
//  p.idList();
//*/
//
///*
//    vector<Token> tokens = {
//            Token(ID,"Ned",2),
//            Token(LEFT_PAREN,"(",2),
//            Token(ID,"Ted",2),
//            Token(COMMA,",",2),
//            Token(ID,"Zed",2),
//            Token(RIGHT_PAREN,")",2),
//    };
//*/
//
//
//int main(int argc, char* argv[]) {
//    ifstream inFile;
//    inFile.open(argv[1]);
//    //int line = 0;
//    string s;
//    string inputs = "";
//    vector<Token> tokens;
//    int toks = 0;
//
//
//    while (getline(inFile, s)) {
//        inputs += s + "\n";
//    }
//
//    Scanner strings = Scanner(inputs);
//    Token t = Token(UNDEFINED, "y", 0);
//    while (t.getType() != EOFILE) {
//        t = strings.scanToken();
//        tokens.push_back(t);
//        toks++;
//    }
//    for (unsigned int i = 0; i < tokens.size(); i++) {
//        if (tokens.at(i).getType() == COMMENT) {
//            tokens.erase(tokens.begin() + i);
//            i--;
//        }
//    }

//  Token t = Token(COMMA, ",", 2);
/*
    for (auto & token : tokens) {
        cout << token.toString() << endl;
    }
    cout << "Total Tokens = " << toks << endl;
*/
//    DatalogProgram data;
//    Parser p = tokens;
//    try {
//        p.datalogProgram();
//        //cout << p.getProgram().toString();
//    } catch (Token t) {
//        cout << "Failure!" << endl;
//        cout << "  " << t.toString() << endl;
//    }
//
//    // Project 3
//
//    Interpreter inter = Interpreter();
//    inter.addScheme(p.getProgram().getScheme());
//    inter.addFacts(p.getProgram().getFact());
//    cout << "Rule Evaluation" << endl;
//    inter.evaluateRules(p.getProgram().getRule()); // Project 4
//    while (inter.repeats()){
//        inter.evaluateRules(p.getProgram().getRule());
//    }
//    cout << endl;
//    cout << "Schemes populated after " << inter.getPasses() << " passes through the Rules." << endl << endl;
//    inter.evaluateQueries(p.getProgram().getQuery());
//
//    return 0;
//}
//
//    // Project 4
//int main() {
//
//    Relation studentRelation("students", Scheme( {"ID", "Name", "Major"} ));
//
//
//    Relation studentRelations("people", Scheme( {"Size", "Name", "Left"} ));
//    vector<string> studentValues[] = {
//            {"'42'", "'Ann'", "'CS'"},
//            {"'64'", "'Ned'", "'EE'"},
//    };
//    vector<string> studentValue[] = {
//            {"'56'", "'Ann'", "'CC'"},
//            {"'54'", "'Ned'", "'EE'"}, // need to loop through the second row
//    };
//
//    for (auto& value : studentValues)
//        studentRelation.addTuple(Tuple(value));
//
//    for (auto& value : studentValue)
//        studentRelations.addTuple(Tuple(value));
//
//    studentRelation.join(studentRelations);
//
//}

//lab 5
int main() {

    // predicate names for fake rules
    // first is name for head predicate
    // second is names for body predicates
    pair<string,vector<string>> ruleNames[] = {
            { "A", { "B", "C" } },
            { "B", { "A", "D" } },
            { "B", { "B" } },
            { "E", { "F", "G" } },
            { "E", { "E", "F" } },
    };

    vector<Rule> rules;

    for (auto& rulePair : ruleNames) {
        string headName = rulePair.first;
        Rule rule = Rule(Predicate(headName));

        vector<string> bodyNames = rulePair.second;
        for (auto& bodyName : bodyNames)
            rule.addBodyPredicate(Predicate(bodyName));
        rules.push_back(rule);
    }

    Graph graph = Interpreter::makeGraph(rules);
    cout << graph.toString();

}