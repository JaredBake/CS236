#pragma once
#include <iostream>
#include "Predicate.h"

using namespace std;

class Rule {
    Predicate* headPredicate;
    Predicate altHead;
    vector<Predicate*> predicates;
    vector<Predicate> altPredicates;

public:

    Rule(){}



    Rule(Predicate* head, vector<Predicate*> preds){
        headPredicate = head;
        predicates = preds;
    }

    int size(){
        return altPredicates.size();
    }

    Rule(Predicate head){
        altHead = head; // maybe need to remove later

        headPredicate = &head;
    }

    Predicate* getHead(){
        return headPredicate;
    }

    Predicate altGetHead(){
        return altHead;
    }

    vector<Predicate> getPredicates(){
        //return predicates; // change back
        return altPredicates;
    }

    void addBodyPredicate(Predicate newPred){
        altPredicates.push_back(newPred); // not a pointer
    }

    Predicate getBodyPredicate(unsigned i){
        return altPredicates.at(i); // not a pointer
    }

    void assignPredicates(vector<Predicate*> rules){
        predicates == rules;
    }


    string toString(){
        string output = "";

        output.append(altHead.toString());
        output.append(" :- ");
        for (unsigned int i = 0; i < altPredicates.size(); i++)
        {
            output.append(altPredicates.at(i).toString());
            if (i < altPredicates.size()-1) {
                output.append(",");
            }
        }
        output.append(".\n");


        return output;
    }
};