#include <iostream>
#include "Token.h"
#include "Scanner.h"

int main() {
  Scanner s = Scanner(",,");
  Token t = s.scanToken();
//  Token t = Token(COMMA, ",", 2);
  cout << t.toString() << endl;

   return 0;
}
