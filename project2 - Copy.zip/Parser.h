#pragma once
#include <string>
#include <vector>
#include "Token.h"
#include "DatalogProgram.h"
#include "Predicate.h"
#include "Parameter.h"


using namespace std;

class Parser {
private:
    vector<Token> tokens;
    DatalogProgram program;
    vector<Parameter*> params;
    vector<Predicate*> rulers;
    Predicate head;
    vector<Parameter*> dom;


public:
    Parser(const vector<Token>& tokens) : tokens(tokens) {}

//    void getTokens(vector<Token> tok){
//        tok = tokens;
//    }

    TokenType tokenType() const {
        return tokens.at(0).getType();
    }
    void advanceToken() {
        tokens.erase(tokens.begin());
    }
    void throwError() {
//        string error = "Failure!";
        throw tokens.at(0);
    }


    void match(TokenType t) {

        //cout << "match: " << t << endl;
        // add code for matching token type t
        if (tokenType() == SCHEMES && tokens.at(2).getType() == FACTS){
            throw tokens.at(2);
        }
        else if(tokenType() == QUERIES && tokens.at(2).getType() == EOFILE){
            throw tokens.at(2);
        }
        if (tokenType() == t) {
            advanceToken();
        } else {
            throwError();
        }
    }

    void parameter(){
        if (tokenType() == STRING){
            params.push_back(new Parameter(tokens.at(0).getName()));
            match(STRING);
        }
        else{
            params.push_back(new Parameter(tokens.at(0).getName()));
            match(ID);
        }
    }




    void stringList(){
        if (tokenType() == COMMA){
            match(COMMA);
            params.push_back(new Parameter(tokens.at(0).getName()));
            dom.push_back(new Parameter(tokens.at(0).getName()));
            program.addDomain(dom.at(0));
            dom.clear();
            match(STRING);
            stringList();
        }
        else{
            //lambda
        }
    }
    void parameterList(){
        if (tokenType() == COMMA){
            match(COMMA);
            parameter();
            parameterList();
        }
        else{
            //lambda
        }
    }
    void predicate(){
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == ID){
            string id = tokens.at(0).getName();
            params.clear();
            match(ID);
            match(LEFT_PAREN);
            parameter();
            parameterList();
            match(RIGHT_PAREN);

            Predicate* p = new Predicate(id, params);
            rulers.push_back(p);

            //program.addScheme(rulers.at(0));
        }
    }
    void predicateList(){
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == COMMA){
            match(COMMA);
            predicate();
            predicateList();
        }
        else{
            //lambda
        }
    }

    void idList() {
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == COMMA) {
            match(COMMA);
            params.push_back(new Parameter(tokens.at(0).getName()));
            match(ID);
            idList();
        } else {
            // lambda
        }
    }



    void scheme()  {
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if(tokenType() == ID) {
            params.clear();
            rulers.clear();
            string id = tokens.at(0).getName();

            match(ID);
            match(LEFT_PAREN);
            params.push_back(new Parameter(tokens.at(0).getName()));
            match(ID);
            idList();
            match(RIGHT_PAREN);



            Predicate* p = new Predicate(id, params);
            rulers.push_back(p);
            program.addScheme(rulers.at(0));

        }
    }
    void fact(){
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == ID){
            params.clear();
            rulers.clear();
            string id = tokens.at(0).getName();

            match(ID);
            match(LEFT_PAREN);
            params.push_back(new Parameter(tokens.at(0).getName()));
            dom.push_back(new Parameter(tokens.at(0).getName()));
            program.addDomain(dom.at(0));
            dom.clear();

            match(STRING);
            stringList();
            match(RIGHT_PAREN);
            match(PERIOD);

//            dom.push_back(new Parameter(tokens.at(0).getName()));
//            program.addDomain(dom.at(0));
//            dom.clear();

//            program.addDomain(dom.at(0));
            dom.clear();
            Predicate* p = new Predicate(id, params);
            rulers.push_back(p);
            program.addFact(rulers.at(0));

        }
    }
    void rule(){
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == ID) {
            params.clear();
            rulers.clear();

            headPredicate();
            match(COLON_DASH);
            predicate();
            predicateList();
            match(PERIOD);

            Rule* r = new Rule(head, rulers);

            program.addRule(r);


        }
    }
    void query(){
        if (tokenType() == COMMENT){
            match(COMMENT);
        }
        if (tokenType() == ID){
            params.clear();
            rulers.clear();

            string id = tokens.at(0).getName();
            params.clear();
            predicate();
            match(Q_MARK);


//            dom.push_back(new Parameter(tokens.at(0).getName()));
//            program.addDomain(dom.at(0));
//            dom.clear();

            Predicate* p = new Predicate(id, params);
            rulers.push_back(p);
            program.addQuery(rulers.at(0));

        }
    }



    void headPredicate(){
//        if (tokenType() == COMMENT){
//            match(COMMENT);
//        }
        if (tokenType() == ID){

            string id = tokens.at(0).getName();


            match(ID);
            match(LEFT_PAREN);

            params.push_back(new Parameter(tokens.at(0).getName()));
            match(ID);

            idList();

            match(RIGHT_PAREN);

            Predicate* p = new Predicate(id, params);
            rulers.push_back(p);
            head = *rulers.at(0);

//            Rule* r = new Rule(rulers.at(0), params);
//            rulers.push_back(r);
//            program.addRule(rulers.at(0));
            rulers.clear();
            params.clear();
        }
    }



    void schemeList(){
//        if (tokenType() == COMMENT){
//            match(COMMENT);
//        }
        if (tokenType() == ID){
            scheme();
            schemeList();
        }
        else{
            //lambda
        }
    }
    void factList(){
//        if (tokenType() == COMMENT){
//            match(COMMENT);
//        }
        if (tokenType() == ID){
            fact();
            factList();
        }
        else{
            //lambda
        }
    }
    void ruleList(){
//        if (tokenType() == COMMENT){
//            match(COMMENT);
//        }
        if (tokenType() == ID){
            rule();
            ruleList();
        }
        else{
            //lambda
        }
    }
    void queryList(){
//        if (tokenType() == COMMENT){
//            match(COMMENT);
//        }
        if (tokenType() == ID){
            query();
            queryList();
        }
        else{
            //lambda
        }
    }

    const DatalogProgram &getProgram() const {
        return program;
    }

    void setProgram(const DatalogProgram &program) {
        Parser::program = program;
    }

    void datalogProgram() {
        match(SCHEMES);
        match(COLON);
        scheme();
        schemeList();


        match(FACTS);
        match(COLON);
        factList();
        match(RULES);
        match(COLON);
        ruleList();
        match(QUERIES);
        match(COLON);
        query();
        queryList();
        match(EOFILE);

    }
};
