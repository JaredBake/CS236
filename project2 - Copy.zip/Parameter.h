#pragma once
#include <vector>
#include <string>

class Parameter {
private:
    string parameter;


public:
    Parameter(string id){
        parameter = id;
    }

    string toString(){
        return parameter;
    }
};