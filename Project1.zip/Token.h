#pragma once

#include <string>
#include <sstream>

using namespace std;

enum TokenType {
   COMMA, PERIOD, COLON
};

class Token {
 private:
   TokenType type;
   string value;  //do we need it to be a char* Nope
   int line;

 public:
   Token(TokenType type, string value, int line ) : type(type), value(value), line(line)  { }


string toString() const {
    stringstream out;  //Put all of these charactor in a string
    out << "(" << typeName(type) << "," << "\"" << value << "\"" << "," << line << ")";
    return out.str();
  }

  string typeName(TokenType type) const {
	switch(type){
	case PERIOD:
		//cout << "Period " << endl;
		return "Period ";
	case COMMA:
		// << "Comma " << endl;
		return "Comma ";
	case COLON:

		return "Colon ";
	}
	return "Does not exist!";
 // return the correct string for each TokenType value
  }
};
