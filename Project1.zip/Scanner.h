#pragma once
#include "Token.h"
#include <cctype>

class Scanner {
 private:
  string input;
  
 public:
  Scanner(const string& input) : input(input) { }

  Token scanToken() {
    TokenType type = COMMA;
    string value = ",";
    int line = 4;
    while(isspace(input.at(0))){
	input = input.substr(1);
    }
    if(input.at(0) == ','){
	return Token(TokenType::COMMA,value,line);

    }

    return Token(type, value, line);
  }


};
