#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <set>
#include <map>
#include <vector>
#include "Scheme.h"
#include "Tuple.h"

using namespace std;


class Relation {

private:

    string name;
    set<Tuple> tuples;
    vector<int> indexes;
    Scheme scheme;
public:

    Relation(){}


    Relation(const string& name, const Scheme& scheme)
            : name(name), scheme(scheme) { }

    bool addTuple(Tuple tuple) {

        return tuples.insert(tuple).second;
    }

    Scheme getScheme(){
        return scheme;
    }

    void setName(string newname){
        name = newname;
    }

//    bool findDups(Tuple tuple){
//        for (unsigned int i = 0; i < .size(); ++i) {
//            bool foundDupe = true;
//            for (unsigned int j = 0; j < tuple.getValues().size(); ++j) {
//                if (.find(i).getTuple(j) != tuple.getTuple(j)){
//                    foundDupe = false;
//                    break;
//                }
//            }
//            if (foundDupe) return true;
//        }
//        return false;
//    }

    int getSize(){
        return tuples.size();
    }

    set<Tuple> getTuples(){
        return tuples;
    }
    string getName(){
        return name;
    }


    string toString() const {
        string output;
        for (auto& tuple : tuples) {
            output.append(tuple.toString(scheme));
        }
        return output;
    }



    Relation select1(int index, string value) {
        Relation result(name, scheme);
        for(Tuple t: tuples){
            if (t.getTuple(index) == value)     // what is the value doing?
            {
                //cout << "variable: " << value << endl;
                result.addTuple(t);
            }

        }
        return result;
    }

    Relation select2(int index1, int index2){  // This select is only comparing the same string to itself
        Relation result(name, scheme);          // I need to figure out how to compare the string I have with the string in facts
        for(Tuple t: tuples){
            if (t.getTuple(index1) == t.getTuple(index2))
            {
                //cout << "index1: " << t.getTuple(index1) << endl;
                //cout << "index2: " << t.getTuple(index2) << endl;
                result.addTuple(t);
            }

        }
        return result;
    }


    Relation project(vector<int> columns){  // Might need to edit with Project 4

        vector<string> s;
        for (unsigned i = 0; i < scheme.attributes.size(); ++i) {

            s.push_back(scheme.getAttribute(i));
        }
        Scheme newScheme(s);
        Relation result(name, newScheme);

        for(Tuple t: tuples){
            Tuple newTuple;
            for (unsigned i = 0; i < columns.size(); ++i) {
                newTuple.push_back(t.getTuple(columns.at(i)));
            }
            result.addTuple(newTuple);
        }
        return result;
    }


    Relation rename(vector<string> names){
        vector<string> s;
        string newname = "";
        for (unsigned i = 0; i < names.size(); ++i) {
            s.push_back(names.at(i));
            newname.append(names.at(i));
        }
        Scheme newScheme(s);
        setName(newname);
        Relation result(name, newScheme);
        for(Tuple t: tuples){
            result.addTuple(t);
        }

// element zero is the name of column zero


        return result;
    }




    Relation join(Relation& right){
        Relation& left = *this;
        Scheme s = left.scheme;
        bool added = false;
        unsigned int i = 0;
        for (string secondName : right.scheme.attributes) {
            unsigned int index = 0;
            added = false;
            for (string firstName : left.scheme.attributes) {
                if (secondName == firstName){
                    break;
                }else{
                    if (index == left.scheme.size()-1) {
                        s.addScheme(secondName);
                        added = true;
                    }
                }
                index++;
            }
            if (added){
                indexes.push_back(i);
            }
            i++;
        }

        Relation result(name,s); // create a new Relation with the new scheme

        for (Tuple leftTuple : left.tuples) {
            //cout << "left tuple: " << leftTuple.toString(left.scheme) << endl;
            for (Tuple rightTuple: right.tuples) {
                //cout << "right tuple: " << rightTuple.toString(right.scheme) << endl;
                if (joinable(left.scheme, right.scheme, leftTuple, rightTuple)){
                    Tuple t = leftTuple;
                    for (int i : indexes) {
                        t.push_back(rightTuple.at(i));
                    }
                    result.addTuple(t);
                }
            }
        }

        return result;
    }

    static bool joinable(const Scheme& leftScheme, const Scheme& rightScheme,
                         const Tuple& leftTuple, const Tuple& rightTuple){

        for (unsigned leftIndex = 0; leftIndex < leftScheme.size(); leftIndex++) {
            const string& leftName = leftScheme.at(leftIndex);
            const string& leftValue = leftTuple.at(leftIndex);
            //cout << "left name: " << leftName << " value: " << leftValue << endl;
            for (unsigned rightIndex = 0; rightIndex < rightScheme.size(); rightIndex++) {
                const string& rightName = rightScheme.at(rightIndex);
                const string& rightValue = rightTuple.at(rightIndex);
                //cout << "right name: " << rightName << " value: " << rightValue << endl;
                if(leftName == rightName){
                    if (leftValue != rightValue){
                        return false;
                    }
                }

            }
        }
        //cout << matches << endl;
        return true;
    }


//    Scheme joinSchemes(){
//
//    }
//
//    Tuple joinTuples(){
//
//    }


};
