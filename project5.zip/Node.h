#pragma once
#include <iostream>
#include <set>
#include "Interpreter.h"


using namespace std;


class Node {

private:
    //unsigned int postOrderNumber;
    bool visited;
    set<int> adjacentNodeIDs;
    bool empty = false;

public:

    void addEdge(int adjacentNodeID) {
        adjacentNodeIDs.insert(adjacentNodeID);
    }

    set<int> getNode(){
        return adjacentNodeIDs;
    }

    bool check(){
        return visited;
    }

    void setVisited(){
        visited = true;
    }

    void clearFlags(){
        visited = false;
    }

    bool isEmpty(){
        if (adjacentNodeIDs.size() == 0){
            empty = true;
        }
        return empty;
    }

    string toString(){
        string output = "";
        for(unsigned int i : adjacentNodeIDs){
            output.append("R");
            output.append(to_string(i));
            output.append(",");
        }
        output.pop_back();
        return output;
    }

};