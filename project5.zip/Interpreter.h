#pragma once
#include <string>
#include <unordered_map>
#include <stack>
#include "Rule.h"
#include "Predicate.h"
#include "DatalogProgram.h"
#include "Relation.h"
#include "Database.h"
#include "Graph.h"
#include "Node.h"

using namespace std;

class Interpreter {
private:
    int passes = 0;
    bool repeat = false;
    //bool end = false;
    Database data;
    unordered_map<string,int> variables;
    vector<int> indexes;
    vector<string> names;

    Graph reverseGraph;


public:

    Interpreter(Graph reverseGraph) : reverseGraph(reverseGraph) {
        data = Database();

    }


//    unordered_map<string, int> getVariables(){
//        return variables;
//    }

    Graph makeGraph(const vector<Rule*> rules) {
        /*
         * Why does it say not to add teh same node more than once to the graph
         * */
        //stack<int> postNumbers;

        Graph graph(rules.size());
        Graph thing(rules.size());
        reverseGraph = thing;
        for (unsigned fromID = 0; fromID < rules.size(); fromID++) {
            Rule* fromRule = rules.at(fromID);
            //cout << "from rule R" << fromID << ": " << fromRule.toString();
            for (int pred = 0; pred < fromRule->size(); pred++) {
                Predicate* bodyPred = fromRule->getBodyPredicate(pred);
                //cout << "from body predicate: " << bodyPred.toString() << endl;
                for (unsigned toID = 0; toID < rules.size(); toID++) {
                    Rule* toRule = rules.at(toID);
                    //6cout << "to rule R" << toID << ": " << toRule->toString();
                    if (toRule->getHead()->getName() == bodyPred->getName()) {
                        //cout << "dependency found: (R" << fromID << ",R" << toID << ")" << endl;
                        graph.addEdge(fromID,toID);
                        reverseGraph.addEdge(toID,fromID);
                    }
                }

            }
        }
        // Run the DFS
        reverseGraph.postDFS();
//        graph.DFS();
        reverseGraph.clearFlags();
        graph.setOrder(reverseGraph.getOrder());
        graph.DFS();
        reverseGraph = graph;
//        graph.postDFS();
//        graph.clearFlags();
//        graph.DFS();
        //reverseGraph.DFS();
        return graph;

    }

    void evaluateRule(Rule* R, set<int> treesers) {
        repeat = false;
        //end = false;
        vector<Predicate *> predicates;
        vector<Relation> result;
        predicates = R->getPredicates();
        //cout << R->toString();
        for (Predicate *p: predicates) {
            Relation r = evaluateQuery(p);
            result.push_back(r);
            //cout << r.toString();
        }
        Relation endResult = result.at(0);
        endResult = endResult.join(endResult);
        //cout << "joining rules" << endl;
        for (unsigned int i = 1; i < result.size(); i++) {
            endResult = endResult.join(result.at(i));
        }
        //cout << endResult.toString();
        // Write code to get indexes for the project function
        Predicate *head = R->getHead();
        vector<string> keys = translateParams(head->getParams());
        vector<string> attribute = endResult.getScheme().getNames();
        indexes.clear();
        names.clear();

        for (unsigned int i = 0; i < keys.size(); i++) {
            for (unsigned int j = 0; j < attribute.size(); ++j) {
                if (keys.at(i) == attribute.at(j)) {
                    indexes.push_back(j);
                    names.push_back(keys.at(i));
                }
            }
        }
        //cout << "HERE" << endl;
        endResult = endResult.project(indexes);
        endResult = endResult.rename(names);
        names.clear();
        unordered_map<string, Relation> m = data.getMap();
        Relation r = m.find(head->getName())->second;
        for (unsigned int i = 0; i < endResult.getScheme().getNames().size(); ++i) {
            names.push_back(r.getScheme().getAttribute(i));
        }
        endResult = endResult.rename(names);
        //cout << endResult.toString();
        cout << R->toString();
        // call project on the joined relation to match the head predicate
        Relation *rate = &data.getMap().find(head->getName())->second;
        Union(endResult, rate);
        if (R->getPredicates().size() == 1){
            if (repeat && R->getPredicates().at(0)->getName() == head->getName()){
                repeat = true;
            }else if (repeat && treesers.size() > 1){
                repeat = true;
            }else{
                repeat = false;
            }
        }else if (repeat && treesers.size() > 1) {
            repeat = true;
        }else if(!findPair(R)){
            repeat = false;
        }


    }

    bool findPair(Rule* r){
        for (Predicate* p : r->getPredicates()) {
            if (r->getHead()->getName() == p->getName()){
                return true;
            }
        }
        return false;
    }

    void evaluateRules(vector<Rule*> rules) {
        repeat = false;
        if (reverseGraph.getForest().empty()){}
        for (set<int> trees: reverseGraph.getForest()) {
            string output = "";
            output.append("SCC: ");
            for (int i: trees) {
                output.append("R");
                output.append(to_string(i));
                output.append(",");
            }
            output.pop_back();
            cout << output << endl;
            passes = 0;
            unsigned int f;
            do {
                f = 0;
                for (int nodes: trees) {
                    Rule *R = rules.at(nodes);
                    evaluateRule(R, trees);
                    if (repeat){
                        f++;
                    }
                }
                passes++;
            } while (f != 0 );
            output.clear();
            output.append(to_string(passes));
            output.append(" passes: ");
            for (int i: trees) {
                output.append("R");
                output.append(to_string(i));
                output.append(",");
            }
            output.pop_back();
            cout << output << endl;

        }
    }


//    void printPasses(int num){
//        cout << passes << " passes: R" << num << endl;
//    }

    void Union(Relation newRelation, Relation* oldRelation){
        for (Tuple t : newRelation.getTuples()) {
            if (oldRelation->addTuple(t)){
                //cout << "already in there" << endl;
                cout << t.toString(newRelation.getScheme());
                //printPasses();
                repeat = true;
                //end = true;
            }
        }
    }

//    int getPasses(){
//        return passes;
//    }


    void evaluateQueries(vector<Predicate*> queries){
        //cout << "IN EVALUATE QUERIES!" << endl;
        cout << "Query Evaluation" << endl;
        for (Predicate* query: queries){

            Relation r = evaluateQuery(query);
            cout << query->toString() << "? ";
            if (r.getSize() == 0){
                cout << "No\n";
            }
            else{
                cout << "Yes(" << r.getSize() << ")\n";
                if (query->getParams().size() > 0){
                    cout << r.toString();
                }
            }
        }
    }

    void addFacts(vector<Predicate*> facts){
        for (Predicate* f: facts) {
            string name = f->getName();
            Tuple fact = Tuple();
            vector<string> strings;
            strings = translateParams(f->getParams());
            for (unsigned int i = 0; i < strings.size(); ++i) {
                fact.push_back(strings.at(i));
            }

            // put tuple in fact
            data.addFactToRelation(fact, name);
            //data.getRelation(name).addTuple(fact);
        }
    }

    void addScheme(vector<Predicate*> schemes){
        for (Predicate* p: schemes) {
            string name = p->getName();
            Scheme scheme = Scheme();
            // put params in scheme
            scheme.assignAttributes(translateParams(p->getParams()));
            Relation r(name,scheme);
            data.addRelationToMap(name,r);
        }
    }

    vector<string> translateParams(vector<Parameter*> param){
        vector<string> strings;
        for(Parameter* p: param){
            strings.push_back(p->toString());
        }
        return strings;
    }

//    bool repeats(){
//        return repeat;
//    }


    Relation evaluateQuery(Predicate* query){
//        cout << "IN EVALUATE QUERY!" << endl;
        //cout << "Evaluating query!" << endl;
        variables.clear();
        names.clear();
        indexes.clear();
        Relation r = data.getRelation(query->getName());
        for(unsigned i = 0; i < query->getParams().size(); i++){

            vector<Parameter*> p = query->getParams();
            if (p.at(i)->getBool()){
                r = r.select1(i, p.at(i)->toString());
            }
            else{
                if (variables.find(p.at(i)->toString()) == variables.end()){
                    variables.insert({p.at(i)->toString(),i});
                    indexes.push_back(i);
                    names.push_back(p.at(i)->toString());

                }else {
                    r = r.select2(variables.find(p.at(i)->toString())->second, i);
                }
            }
        }

        r = r.project(indexes);
        r = r.rename(names);

        return r;
    }



};