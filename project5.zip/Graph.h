#pragma once
#include <iostream>

#include "Interpreter.h"
#include "Node.h"


class Graph {

private:

    map<int,Node> nodes;
    stack<int> postOrder;
    set<int> tree;
    vector<set<int>> forest;

public:

    Graph(unsigned int size) {
        for (unsigned int nodeID = 0; nodeID < size; nodeID++)
            nodes[nodeID] = Node();
    }

    vector<set<int>> getForest(){
        return forest;
    }

//    map<int, Node> getNodes(){
//        return nodes;
//    }
    stack<int> getOrder(){
        return postOrder;
    }

    void setOrder(stack<int> order){
        postOrder = order;
    }

//    Node findNode(int i){
//        cout << nodes.at(i).toString();
//        return nodes.at(i);
//    }
    void postDFS() {
        unsigned int i = 0;
        for (auto &adjList: nodes) {
            if (!adjList.second.check()) {
                post_dFS(adjList.first);
            }
            //cout << endl;
            i++;
        }
//        int size = postOrder.size();
//        for (int j = 0; j < size; ++j) {
//            cout << postOrder.top() << endl;
//            postOrder.pop();
//        }
    }
    void clearFlags(){
        for(auto &flags : nodes){
            flags.second.clearFlags();
        }
    }
    void post_dFS(int key){
        nodes.at(key).setVisited();
        for (auto &adjList : nodes.at(key).getNode()) {
            if (!nodes.at(adjList).check()) {
                nodes.at(adjList).setVisited();
                post_dFS(adjList);
            }
        }
        postOrder.push(key);
    }

    void DFS() {
        vector<int> newOrder;
        unsigned int size = postOrder.size();
        for (unsigned int i = 0; i < size; ++i) {
            newOrder.push_back(postOrder.top());
            //cout << postOrder.top() << ",";
            postOrder.pop();
        }
        for (unsigned int i : newOrder) {
            auto &adjList = nodes.at(i);
            if (!adjList.check()) {
                dFS(i);
            }
            if (!tree.empty()){
                forest.push_back(tree);
                tree.clear();
            }
        }
    }

    void dFS(int key){
        nodes.at(key).setVisited();
        for (auto adjList : nodes.at(key).getNode()) {
            if (!nodes.at(adjList).check()) {
                dFS(adjList);
            }
        }
        tree.insert(key);
    }

    void addEdge(int fromNodeID, int toNodeID) {
        nodes[fromNodeID].addEdge(toNodeID);
    }

    string toString(){
        string output;
        for (auto& pair: nodes) {
            int nodeID = pair.first;
            Node node = pair.second;
            output.append("R");
            output.append(to_string(nodeID));
            output.append(":");
            if (!node.isEmpty()) {
                output.append(node.toString());
            }
            output.append("\n");
        }
        output.pop_back();
        return output;
    }

};