#pragma once
#include <iostream>
#include "Predicate.h"

using namespace std;

class Rule {
    Predicate* headPredicate;
    //Predicate altHead;
    vector<Predicate*> predicates;
    //vector<Predicate> altPredicates;

public:

    Rule(){}



    Rule(Predicate* head, vector<Predicate*> preds){
        headPredicate = head;
        predicates = preds;
    }

    int size(){
        return predicates.size();
    }

    Rule(Predicate* id){
        headPredicate = id; // maybe need to remove later
    }

    Predicate* getHead(){
        return headPredicate;
    }

//    Predicate altGetHead(){
//        return altHead;
//    }

    vector<Predicate*> getPredicates(){
        return predicates; // change back
        //return altPredicates;
    }

    void addBodyPredicate(Predicate* newPred){
        predicates.push_back(newPred); // not a pointer
    }

    Predicate* getBodyPredicate(unsigned i){
        return predicates.at(i); // not a pointer
    }

    void assignPredicates(vector<Predicate*> rules){
        predicates == rules;
    }


    string toString(){
        string output = "";

        output.append(headPredicate->toString());
        output.append(" :- ");
        for (unsigned int i = 0; i < predicates.size(); i++)
        {
            output.append(predicates.at(i)->toString());
            if (i < predicates.size()-1) {
                output.append(",");
            }
        }
        output.append(".\n");


        return output;
    }
};