#pragma once
#include <vector>
#include <string>

using namespace std;

class Parameter {
private:
    string parameter;
    bool isConst = false;

public:
//    Parameter(string id){
//        parameter = id;
//    }



    Parameter(Token t){
        assignValue(t);
    }

    void assignValue(Token t){
        this->parameter = t.getName();
        isConst = (t.getType() == STRING);
    }

    bool getBool(){
        return isConst;
    }


    string toString(){
        return parameter;
    }
};