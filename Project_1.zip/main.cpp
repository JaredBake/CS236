#include <iostream>
#include <fstream>
#include <vector>
#include <cctype>
#include "Token.h"
#include "Scanner.h"

using namespace std;

/*

 Scanner::Scanner(istream* in):
  inStream(in),
  lineCount(1),
  colCount(-1),
  needToken(t r u e),
  lastToken(0)
  {}
*/

int main(int argc, char* argv[]) {
    ifstream inFile;
    inFile.open(argv[1]);
    //int line = 0;
    string s;
    string inputs = "";
    vector<Token> tokens;
    int toks = 0;


    while(getline(inFile, s)) {
        inputs += s + "\n";
    }

    Scanner strings = Scanner(inputs);
    Token t = Token(UNDEFINED,"y",0);
    while(t.getType() != EOFILE){
        t = strings.scanToken();
        tokens.push_back(t);
        toks++;
    }

//  Token t = Token(COMMA, ",", 2);

    for (auto & token : tokens) {
        cout << token.toString() << endl;
    }
    cout << "Total Tokens = " << toks << endl;

    return 0;
}
