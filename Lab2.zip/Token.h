
#include <string>
#include <sstream>

using namespace std;

enum TokenType {
    COMMA, PERIOD, COLON,Q_MARK,LEFT_PAREN,RIGHT_PAREN,COLON_DASH,MULTIPLY,ADD,ID,STRING,COMMENT,UNDEFINED,
    SCHEMES,FACTS,RULES,QUERIES,EOFILE
};

class Token {
private:
    TokenType type;
    string value;  //do we need it to be a char* Nope
    int line;

public:
    Token(TokenType type, string value, int line ) : type(type), value(value), line(line)  { }

    string toString() const {
        stringstream out;  //Put all of these charactor in a string
        out << "(" << typeName(type) << "," << "\"" << value << "\"" << "," << line << ")";
        return out.str();
    }

    TokenType getType() const{
        return type;
    }

    string typeName(TokenType type) const {
        switch(type){
            case PERIOD:
                //cout << "Period " << endl;
                return "Period ";
            case COMMA:
                // << "Comma " << endl;
                return "Comma ";
            case COLON:
                return "Colon ";
            case Q_MARK:
                return "Q_Mark ";
            case LEFT_PAREN:
                return "Left_Paren ";
            case RIGHT_PAREN:
                return "Right_Paren ";
            case COLON_DASH:
                return "Colon_Dash ";
            case MULTIPLY:
                return "Multiply ";
            case ADD:
                return "Add ";
            case ID:
                return "ID ";
            case STRING:
                return "String ";
            case COMMENT:
                return "Comment ";
            case UNDEFINED:
                return "Undefined ";
            case EOFILE:
                return "EOF ";
            case SCHEMES:
                return "Schemes ";
            case FACTS:
                return "Facts ";
            case RULES:
                return "Rules ";
            case QUERIES:
                return "Queries ";
                return "Does not exist!";
        }
        // return the correct string for each TokenType value
    }
};

