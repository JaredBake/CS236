//
// Created by 18jab on 2/6/2023.
//

#ifndef LAB2_SCANNER_H
#define LAB2_SCANNER_H

#endif //LAB2_SCANNER_H
