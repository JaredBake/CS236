#include <iostream>
#include <string>
#include <vector>
#include <set>
#include "Tuple.h"
#include "Scheme.h"
#include "Relation.h"

using namespace std;

int main() {

    Scheme scheme1( { "cat", "dog", "fish" } );
    Scheme scheme2( { "cat", "fish", "bird", "bunny" } );

    Tuple tuple1( {"'1'", "'2'", "'5'"} );
    Tuple tuple2( {"'1'", "'5'", "'8'", "'3'"} );

//    Relation::joinable(scheme1, scheme2, tuple1, tuple2);
//    Scheme scheme3( { "X", "Y" } );
//    Scheme scheme4( { "X", "Y", "Z" } );
//
//    Tuple tuple3( {"'1'", "'4'"} );
//    Tuple tuple4( {"'1'", "'2'", "'4'"} );

    cout << Relation::joinable(scheme1, scheme2, tuple1, tuple2) << endl;
//    cout << Relation::joinable(scheme2, scheme3, tuple1, tuple2) << endl;
//    cout << Relation::joinable(scheme3, scheme4, tuple1, tuple4) << endl;
//    cout << Relation::joinable(scheme3, scheme4, tuple3, tuple4) << endl;
}