#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Scheme.h"
#include "Tuple.h"

using namespace std;


class Relation {

private:

  string name;
  Scheme scheme;
  set<Tuple> tuples;


public:

    Relation(){}
    Relation(const string& name, const Scheme& scheme)
    : name(name), scheme(scheme) { }

    void addTuple(const Tuple& tuple) {
        tuples.insert(tuple);
    }


    string toString() const {
        stringstream out;
        for (auto& tuple : tuples)
            out << tuple.toString(scheme) << endl;
        return out.str();
    }



    Relation select(int index, const string& value) const {
        Relation result(name, scheme);
        for(Tuple t: tuples){
            if (value == t.at(index)){
            result.addTuple(t);
            }

        }
      // add tuples to the result if they meet the condition
        return result;
    }

    Relation join(Relation& right){
        Relation& left = *this;
        Relation result;

        for (Tuple leftTuple : left.tuples) {
            cout << "left tuple: " << leftTuple.toString(left.scheme) << endl;

            for (Tuple rightTuple: right.tuples) {
                cout << "right tuple: " << rightTuple.toString(right.scheme) << endl;
            }
        }


        return result;
    }

    static bool joinable(const Scheme& leftScheme, const Scheme& rightScheme,
                         const Tuple& leftTuple, const Tuple& rightTuple){
        bool matches = false;
        for (unsigned leftIndex = 0; leftIndex < leftScheme.size(); leftIndex++) {
            const string& leftName = leftScheme.at(leftIndex);
            const string& leftValue = leftTuple.at(leftIndex);
            cout << "left name: " << leftName << " value: " << leftValue << endl;
            for (unsigned rightIndex = 0; rightIndex < rightScheme.size(); rightIndex++) {
                const string& rightName = rightScheme.at(rightIndex);
                const string& rightValue = rightTuple.at(rightIndex);
                cout << "right name: " << rightName << " value: " << rightValue << endl;
                if(leftName == rightName){
                    if (leftValue == rightValue){
                        matches = true;
                        cout << matches << endl;
                        if (leftIndex-1 == leftScheme.size() && rightIndex-1 == rightScheme.size()){
                            return matches;
                        }

                    }
                }

            }
        }
        //cout << matches << endl;
        return matches;
    }


    Scheme joinSchemes(){

    }

    Tuple joinTuples(){

    }


};
