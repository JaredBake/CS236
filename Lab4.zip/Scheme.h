#pragma once
#include <vector>
#include <string>

using namespace std;

class Scheme : public vector<string> {
private:
    vector<string> names;

 public:

    Scheme(){}

    Scheme(vector<string> namer) : names(namer) { }

    unsigned  size() const {
        return names.size();
    }

    const string& at(int index) const{
        return names.at(index);
    }

    vector<string> getNames(){
        return names;
    }

};