#pragma once
#include <string>
#include "Predicate.h"
#include "DatalogProgram.h"
#include "Relation.h"
#include "Database.h"

using namespace std;

class Interpreter {
private:
    Database data;
//    DatalogProgram dp;
//    vector<Relation> relations;

public:

    Interpreter(){
        data = Database();
    }


    void evaluateQueries(vector<Predicate*> queries){
        cout << "IN EVALUATE QUERIES!" << endl;
        for (Predicate* query: queries){

            Relation r = evaluateQuery(query);
            cout << "Getting ready to print Queries!" << endl;
            cout << query->toString() << "? ";
            if (r.getSize() == 0){
                cout << "No\n";
            }
            else{
                cout << "Yes(" << r.getSize() << ")\n";
                if (query->getParams().size() > 0){
                    cout << r.toString();
                }
            }
        }
    }

    void addFacts(vector<Predicate*> facts){
        for (Predicate* f: facts) {
            string name = f->getName();
            Tuple fact = Tuple();
            // put tuple in scheme
            data.addFactToRelation(fact, name);
        }
    }

    void addScheme(vector<Predicate*> schemes){
        for (Predicate* p: schemes) {
            string name = p->getName();
            Scheme scheme = Scheme();
            // put params in scheme
            scheme.assignAttributes(translateParams(p->getParams()));
            Relation r(name,scheme);
            data.addRelationToMap(name,r);
        }
    }

    vector<string> translateParams(vector<Parameter*> param){
        vector<string> strings;
        for(Parameter* p: param){
            strings.push_back(p->toString());
        }
        return strings;
    }

//    vector<int> makeVector(map<string, int> vars){
//        vector<int> index;
//
//
//        for (string name: vars.first()) {
//
//        }
//
//        return index;
//    }


    Relation evaluateQuery(Predicate* query){
//        cout << "IN EVALUATE QUERY!" << endl;
//        cout << "Got name" << endl;
        cout << "Got index" << endl;
        map<string,int> variables = map<string, int>();
        Relation r = data.getRelation(query->getName());
        for(unsigned i = 0; i < query->getParams().size(); i++){
            cout << "Evaluating query!" << endl;
            Parameter* p = query->getParams().at(i);
            if (p->getBool()){
                r = r.select1(i, p->toString());
            }
            else{
                if (variables.find(p->toString()) == variables.end()){
                    variables.insert({p->toString(),i});
                }
                for (unsigned j = 0; j < query->getParams().size(); ++j) {
                    if (!query->getParams().at(i)->getBool() && (p->toString() == query->getParams().at(j)->toString())) {
                        r = r.select2(i, j);
                        break;
                    }
                }
                vector<int> indexes;
                vector<string> names;
                for (auto &x: variables) indexes.push_back(x.second);
                r = r.project(indexes);
                if (indexes.size() > 0){
                    for (auto &n: variables) names.push_back(n.first);
                    r = r.rename(names);
                }
            }
        }

        return r;
    }



};