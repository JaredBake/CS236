#pragma once
#include <vector>
#include <set>
#include <list>
#include "Rule.h"
#include "Parser.h"
#include "Parameter.h"
#include "Predicate.h"

using namespace std;

class DatalogProgram {
private:
    vector<Predicate*> schemes;
    vector<Predicate*> facts;
    vector<Predicate*> queries;
    vector<Rule*> rules;
    set<string> Domain;
public:

    DatalogProgram(){};

    void addDomain(Parameter* item){
        Domain.insert(item->toString());
    }

    void addScheme(Predicate *scheme){
        schemes.push_back(scheme);
    }

    void addFact(Predicate *fact){
        facts.push_back(fact);
    }


    void addQuery(Predicate *query){
        queries.push_back(query);
    }

    void addRule(Rule *rule){
        rules.push_back(rule);
    }



    vector<Predicate *> getScheme(){
        return schemes;
    }

    vector<Predicate *> getFact(){
        return facts;
    }

    vector<Predicate *> getQuery(){
        return queries;
    }
//
//    vector<Rule *> getRule(){
//        return rules;
//    }

    string toString() const{
        string output = "";
        output.append("Success!\n");
        output.append("Schemes(");
        output.append(to_string(schemes.size()));
        output.append("):\n");
        for (Predicate* scheme: schemes)
        {
            output.append("  ");
            output.append(scheme->toString());
            output.append("\n");
        }


        output.append("Facts(");
        output.append(to_string(facts.size()));
        output.append("):\n");
        for (Predicate* fact: facts)
        {
            output.append("  ");
            output.append(fact->toString());
            output.append(".");
            output.append("\n");
        }

        output.append("Rules(");
        output.append(to_string(rules.size()));
        output.append("):\n");
        for (Rule* rule: rules)
        {
            output.append("  ");
            output.append(rule->toString());

        }
        //output.append("\n");

        output.append("Queries(");
        output.append(to_string(queries.size()));
        output.append("):\n");
        for (Predicate* query: queries)
        {
            output.append("  ");
            output.append(query->toString());
            output.append("?");
            output.append("\n");

        }
        //output.append("\n");



        output.append("Domain(");
        output.append(to_string(Domain.size()));
        output.append("):\n");


        for (string domain: Domain)
        {

            output.append("  ");
            output.append(domain);
            output.append("\n");
        }


        return output;
    }
};
