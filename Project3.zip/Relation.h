#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Scheme.h"
#include "Tuple.h"

using namespace std;


class Relation {

private:

  string name;
  Scheme scheme;
  set<Tuple> tuples;

public:
    Relation(){}


    Relation(const string& name, const Scheme& scheme)
        : name(name), scheme(scheme) { }

    void addTuple(const Tuple& tuple) {
        tuples.insert(tuple);
    }

    int getSize(){
        int size = 0;
        for (auto& t : tuples) {
            size++;
            t.size();
        }

        return size;
    }

    string getName(){
        return name;
    }


    string toString() const {
        stringstream out;
        for (auto& tuple : tuples)
        out << tuple.toString(scheme) << endl;
        return out.str();
    }



    Relation select1(int index, string value) {
        Relation result(name, scheme);
        for(Tuple t: tuples){
        if (value == t[index])
        {
            result.addTuple(t);
        }
      
        }
        return result;
    }

    Relation select2(int index1, int index2){
        Relation result(name, scheme);
        for(Tuple t: tuples){
            if (t[index1] == t[index2])
            {
                result.addTuple(t);
            }

        }
        return result;
    }


    Relation project(vector<int> columns){

        vector<string> s;
        for (unsigned i = 0; i < columns.size(); ++i) {

            s.push_back(scheme.attributes.at(columns.at(i)));
        }
        Scheme newScheme(s);
        Relation result(name, newScheme);

        for(Tuple t: tuples){
            Tuple newTuple;
            for (unsigned i = 0; i < columns.size(); ++i) {
                newTuple.push_back(t.at(columns.at(i)));
            }
            result.addTuple(newTuple);
        }
        return result;
    }


    Relation rename(vector<string> names){
        vector<string> s;
        for (unsigned i = 0; i < names.size(); ++i) {
            s.push_back(names.at(i));
        }
        Scheme newScheme(s);

        Relation result(name, newScheme);
        for(Tuple t: tuples){
            result.addTuple(t);
        }

// element zero is the name of column zero

        return result;
    }




//    Relation join(Relation& right){
//        Relation& left = *this;
//        Relation result;
//
//        for (Tuple leftTuple : left.tuples) {
//            cout << "left tuple: " << leftTuple.toString(left.scheme) << endl;
//            for (Tuple rightTuple : right.tuples){
//                cout << "right tuple: " << rightTuple.toString(right.scheme) << endl;
//            }
//
//        }
//        return result;
//    }


};
