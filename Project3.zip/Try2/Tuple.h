#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Scheme.h"


using namespace std;

class Tuple {
private:
    vector<string> values;
public:
    Tuple(){}
    Tuple(vector<string> values) : values(values) { }

    void push_back(string param){
        values.push_back(param);
    }

    string getTuple(int index){
        string t;
        t = values.at(index);
        return t;
    }

    vector<string> getValues() { return values;}



    string toString(Scheme scheme) const {
        string output;
        // fix the code to print "name=value" pairs

        for (unsigned int i = 0; i < values.size(); i++)
        {
            output.append("  ");
            output.append(scheme.getAttributes(i));
            output.append("=");
            output.append(values.at(i));
            if (i < values.size() - 1) {
                output.append(",");
            }
            if (values.size() != 0 && i == values.size()-1){
                output.append("\n");
            }
        }


        //out << scheme.size();
        //out << scheme.at(0);
        //out << tuple.size();
        //out << tuple.at(0);
        return output;
    }

    bool operator<(const Tuple t) const {
        return values < t.values;
    }
};