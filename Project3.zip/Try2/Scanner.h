#pragma once
#include "Token.h"


#include <iostream>

using namespace std;


class Scanner {
private:
    string input;
    string s;
//    int max=0;
//    TokenType type;
    string value;
    int line = 1;
    int L;
public:
    Scanner(const string &input) : input(input) {}





    Token scanToken() {
        line = line + L;
        L = 0;
        if(input.empty()){
            return Token(TokenType::EOFILE, value, line);
        }
        while(input.at(0) == '\n') {
            input = input.substr(1);
            line++;
            if (input.empty()) {         // if non-zero
                return Token(TokenType::EOFILE, value, line);
            }
        }
        while (isspace(input.at(0))) {
            if(input.at(0) == '\n') {
                input = input.substr(1);
                line++;
                if (input.empty()) {         // if non-zero
                    return Token(TokenType::EOFILE, value, line);
                }
            }
            else {
                input = input.substr(1);
                if (input.empty()) {         // if non-zero
                    return Token(TokenType::EOFILE, value, line);
                }
            }
        }

        if (input.at(0) == ',') {
            input = input.substr(1);
            return Token(TokenType::COMMA, ",", line);
        } else if (input.at(0) == ':' && input.at(1) != '-') {
            input = input.substr(1);
            return Token(TokenType::COLON, ":", line);
        } else if (input.at(0) == '.') {
            input = input.substr(1);
            return Token(TokenType::PERIOD, ".", line);
        } else if (input.at(0) == '?') {
            input = input.substr(1);
            return Token(TokenType::Q_MARK, "?", line);
        } else if (input.at(0) == '(') {
            input = input.substr(1);
            return Token(TokenType::LEFT_PAREN, "(", line);
        } else if (input.at(0) == ')') {
            input = input.substr(1);
            return Token(TokenType::RIGHT_PAREN, ")", line);
        } else if (input.at(0) == ':' && input.at(1) == '-') {
            input = input.substr(2);
            return Token(TokenType::COLON_DASH, ":-", line);
        } else if (input.at(0) == '*') {
            input = input.substr(1);
            return Token(TokenType::MULTIPLY, "*", line);
        } else if (input.at(0) == '+') {
            input = input.substr(1);
            return Token(TokenType::ADD, "+", line);
        } else if (isalpha(input.at(0))) {
            s = "";
            int i = 0;
            while (!input.empty() && isalnum(input.at(i))) {
                s += input.at(i);
                i++;
                //max = i;
                // add Facts Schemes and other stuff here check exact wording for them.
            }
            if (s == "Facts"){
                input = input.substr(5);
                return Token(TokenType::FACTS,s,line);
            }else if (s == "Schemes"){
                input = input.substr(7);
                return Token(TokenType::SCHEMES,s,line);
            }else if (s == "Rules"){
                input = input.substr(5);
                return Token(TokenType::RULES,s,line);
            }else if (s == "Queries"){
                input = input.substr(7);
                return Token(TokenType::QUERIES,s,line);
            }
            input = input.substr(s.size());
            return Token(TokenType::ID, s, line);
        } else if (input.at(0) == '\'') {
            s = "";
            s += input.at(0);
            input = input.substr(1);

            while (!input.empty())
            {
                if (input.at(0) == '\''){
                    s += input.at(0);
                    input = input.substr(1);
                    return Token(TokenType::STRING, s, line);
                }
                if (input.at(0) == '\n'){
                    L++;
                }
                s += input.at(0);
                input = input.substr(1);
            }

            return Token(TokenType::UNDEFINED, s, line);
        } else if (input.at(0) == '#') {
            s = "";
            while (!input.empty() && input.at(0) != '\n')
            {
                s += input.at(0);
                input = input.substr(1);
            }

            return Token(TokenType::COMMENT, s, line);
        } else {
            string v = input.substr(0,1);
            input = input.substr(1);
            return Token(TokenType::UNDEFINED, v, line);
        }
//        input = input.substr(1);
//        return Token(TokenType::EOFILE, value, line);
    }
};

