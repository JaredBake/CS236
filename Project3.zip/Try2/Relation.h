#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <set>
#include <map>
#include <vector>
#include "Scheme.h"
#include "Tuple.h"

using namespace std;


class Relation {

private:

    string name;
    Scheme scheme;
    set<Tuple> tuples;

public:
    Relation(){}


    Relation(const string& name, const Scheme& scheme)
            : name(name), scheme(scheme) { }

    void addTuple(Tuple tuple) {
            tuples.insert(tuple);
    }

//    bool findDups(Tuple tuple){
//        for (unsigned int i = 0; i < tuples.size(); ++i) {
//            bool foundDupe = true;
//            for (unsigned int j = 0; j < tuple.getValues().size(); ++j) {
//                if (tuples.find(i).getTuple(j) != tuple.getTuple(j)){
//                    foundDupe = false;
//                    break;
//                }
//            }
//            if (foundDupe) return true;
//        }
//        return false;
//    }

    int getSize(){
        return tuples.size();
    }

    string getName(){
        return name;
    }


    string toString() const {
        string output;
        for (auto& tuple : tuples) {
            output.append(tuple.toString(scheme));
        }
        return output;
    }



    Relation select1(int index, string value) {
        Relation result(name, scheme);
        for(Tuple t: tuples){
            if (t.getTuple(index) == value)     // what is the value doing?
            {
                //cout << "variable: " << value << endl;
                result.addTuple(t);
            }

        }
        return result;
    }

    Relation select2(int index1, int index2){  // This select is only comparing the same string to itself
        Relation result(name, scheme);          // I need to figure out how to compare the string I have with the string in facts
        for(Tuple t: tuples){
            if (t.getTuple(index1) == t.getTuple(index2))
            {
                //cout << "index1: " << t.getTuple(index1) << endl;
                //cout << "index2: " << t.getTuple(index2) << endl;
                result.addTuple(t);
            }

        }
        return result;
    }


    Relation project(vector<int> columns){  // Might need to edit with Project 4

        vector<string> s;
        for (unsigned i = 0; i < scheme.attributes.size(); ++i) {

            s.push_back(scheme.getAttributes(i));
        }
        Scheme newScheme(s);
        Relation result(name, newScheme);

        for(Tuple t: tuples){
            Tuple newTuple;
            for (unsigned i = 0; i < columns.size(); ++i) {
                newTuple.push_back(t.getTuple(columns.at(i)));
            }
            result.addTuple(newTuple);
        }
        return result;
    }


    Relation rename(vector<string> names){
        vector<string> s;
        for (unsigned i = 0; i < names.size(); ++i) {
            s.push_back(names.at(i));
        }
        Scheme newScheme(s);

        Relation result(name, newScheme);
        for(Tuple t: tuples){
            result.addTuple(t);
        }

// element zero is the name of column zero

        return result;
    }




//    Relation join(Relation& right){
//        Relation& left = *this;
//        Relation result;
//
//        for (Tuple leftTuple : left.tuples) {
//            cout << "left tuple: " << leftTuple.toString(left.scheme) << endl;
//            for (Tuple rightTuple : right.tuples){
//                cout << "right tuple: " << rightTuple.toString(right.scheme) << endl;
//            }
//
//        }
//        return result;
//    }


};
