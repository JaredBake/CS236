#pragma once

#include <vector>
#include <string>
#include <set>
#include <unordered_map>
#include <map>
#include <list>
#include "Relation.h"
#include "Scheme.h"
#include "Tuple.h"
#include "Interpreter.h"
#include "Rule.h"
#include "Parser.h"
#include "Parameter.h"
#include "Predicate.h"

using namespace std;

class Database{
private:
    unordered_map<string, Relation> mapp;
public:


    Database(){
        mapp = unordered_map<string, Relation>();
    }

    unordered_map<string, Relation> getMap(){
        return  mapp;
    }
    void addRelationToMap(string name, Relation r){
        mapp.insert({name,r});
    }

    void addFactToRelation(Tuple t, string name){
        mapp.at(name).addTuple(t);
    }

    Relation getRelation(string key){
        return mapp[key];
    }

    string toString(){
        stringstream output;
        for (auto itr = mapp.begin(); itr != mapp.end(); ++itr) {
            output << (itr->first);
            output << ("\n");
            itr->second.toString();
        }


        return output.str();
    }
};
