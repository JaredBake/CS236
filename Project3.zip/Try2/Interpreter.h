#pragma once
#include <string>
#include <unordered_map>
#include "Predicate.h"
#include "DatalogProgram.h"
#include "Relation.h"
#include "Database.h"

using namespace std;

class Interpreter {
private:
    Database data;
    unordered_map<string,int> variables;
    vector<int> indexes;
    vector<string> names;
public:

    Interpreter(){
        data = Database();
    }

    unordered_map<string, int> getVariables(){
        return variables;
    }


    void evaluateQueries(vector<Predicate*> queries){
        //cout << "IN EVALUATE QUERIES!" << endl;
        for (Predicate* query: queries){

            Relation r = evaluateQuery(query);
            //cout << "Getting ready to print Queries!" << endl;
            cout << query->toString() << "? ";
            if (r.getSize() == 0){
                cout << "No\n";
            }
            else{
                cout << "Yes(" << r.getSize() << ")\n";
                if (query->getParams().size() > 0){
                    cout << r.toString();
                }
            }
        }
    }

    void addFacts(vector<Predicate*> facts){
        for (Predicate* f: facts) {
            string name = f->getName();
            Tuple fact = Tuple();
            vector<string> strings;
            strings = translateParams(f->getParams());
            for (unsigned int i = 0; i < strings.size(); ++i) {
                fact.push_back(strings.at(i));
            }

            // put tuple in fact
            data.addFactToRelation(fact, name);
            //data.getRelation(name).addTuple(fact);
        }
    }

    void addScheme(vector<Predicate*> schemes){
        for (Predicate* p: schemes) {
            string name = p->getName();
            Scheme scheme = Scheme();
            // put params in scheme
            scheme.assignAttributes(translateParams(p->getParams()));
            Relation r(name,scheme);
            data.addRelationToMap(name,r);
        }
    }

    vector<string> translateParams(vector<Parameter*> param){
        vector<string> strings;
        for(Parameter* p: param){
            strings.push_back(p->toString());
        }
        return strings;
    }

//    vector<int> makeVector(map<string, int> vars){
//        vector<int> index;
//
//
//        for (string name: vars.first()) {
//
//        }
//
//        return index;
//    }


    Relation evaluateQuery(Predicate* query){
//        cout << "IN EVALUATE QUERY!" << endl;
        //cout << "Evaluating query!" << endl;
        variables.clear();
        names.clear();
        indexes.clear();
        Relation r = data.getRelation(query->getName());
        for(unsigned i = 0; i < query->getParams().size(); i++){

            vector<Parameter*> p = query->getParams();
            if (p.at(i)->getBool()){
                r = r.select1(i, p.at(i)->toString());
            }
            else{
                if (variables.find(p.at(i)->toString()) == variables.end()){
                    variables.insert({p.at(i)->toString(),i});
                    indexes.push_back(i);
                    names.push_back(p.at(i)->toString());

                }else {
                    r = r.select2(variables.find(p.at(i)->toString())->second, i);
                }






            }
        }

        r = r.project(indexes);
        r = r.rename(names);

        return r;
    }



};