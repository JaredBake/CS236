#pragma once
#include <vector>
#include <string>
#include "Parameter.h"
#include "Token.h"

using namespace std;

class Predicate {
public:
    string name;
    vector<Parameter*> parameters;


public:
    Predicate(string id, vector<Parameter*> params){
        name = id;
        parameters = params;
    }

    Predicate() {}

    string getName(){
        return name;
    }

    vector<Parameter*> getParams(){
        return parameters;
    }


    string toString(){
        string output = "";
        output.append(name);
        output.append("(");
        for (unsigned int i = 0; i < parameters.size(); i++)
        {
            output.append(parameters.at(i)->toString());
            if (i < parameters.size()-1){
                output.append(",");
            }

        }
        output.append(")");

        return output;

    }
};