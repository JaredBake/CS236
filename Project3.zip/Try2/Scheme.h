#pragma once
#include <vector>
#include <string>

using namespace std;

class Scheme {
private:

public:
    vector<string> attributes;

    Scheme(){
        attributes = vector<string>();
    }
    Scheme(vector<string> names) {
        attributes = names;
    }

    void assignAttributes(vector<string> strings){
        attributes = strings;
    }

    string getAttributes(int index){
        string t;
        t = attributes.at(index);
        return t;
    }
};